//
//  Device.swift
//  Living
//
//  Created by Nelson FB on 19/07/16.
//  Copyright © 2016 ar-smart. All rights reserved.
//

import Foundation


class Device{




    func RequestWifiTokenId(){}
    


}