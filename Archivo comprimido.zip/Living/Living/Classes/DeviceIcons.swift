//
//  DeviceIcons.swift
//  Living
//
//  Created by Nelson FB on 28/07/16.
//  Copyright © 2016 ar-smart. All rights reserved.
//



class DeviceIcons{

    var icons: [String] = ["light_icon",
                           "light_2_icon",
                           "light_3_icon",
                           "light_4_icon",
                           "light_5_icon",
                           "hue_icon1",
                           "hue_icon2",
                           "music_icon",
                           "music_2_icon",
                           "music_3_icon",
                           "music_4_icon",
                           "music_5_icon",
                           "power_outlet_icon",
                           "power_outlet_2_icon",
                           "switch_icon",
                           "tv_icon",
                           "door_lock_icon",
                           "door_lock_2_icon",
                           "shades_2_icon",
                           "shades_2_icon",
                           "shades_3_icon",
                           "shades_4_icon",
                           "lamp_icon",
                           "temperature_icon",
                           "sensor_icon",
                           "alarm_icon",
                           "alarm_2_icon",
                           "alarm_3_icon",
                           "battery_icon",    
                           "cofee_maker_icon",    
                           "door_icon",    
                           "door_2_icon",    
                           "energy_icon",    
                           "energy_2_icon",    
                           "energy_sensor_icon",    
                           "power_icon",    
                           "lamp_icon",    
                           "lamp_2_icon",    
                           "lamp_3_icon",    
                           "movement_sensor_icon",    
                           "movement_sensor_2_icon",    
                           "movement_sensor_3_icon",    
                           "movement_sensor_4_icon",    
                           "open_close_sensor_icon",    
                           "open_close_sensor_2_icon",    
                           "open_close_sensor_3_icon",    
                           "water_icon",    
                           "water_2_icon",    
                           "water_3_icon",
                           "default_icon"]
    
    
    
    
    
    
    
}